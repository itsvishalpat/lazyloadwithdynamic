import Header from '../components/Header'

const About = () => (
  <div>
    <Header />
    <p>This is the about page.</p>
  </div>
)

export default About
