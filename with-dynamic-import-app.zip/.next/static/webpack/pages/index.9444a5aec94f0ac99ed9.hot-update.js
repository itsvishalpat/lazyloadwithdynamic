webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Header */ "./components/Header.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dynamic */ "./node_modules/next/dist/next-server/lib/dynamic.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-loading-skeleton */ "./node_modules/react-loading-skeleton/lib/index.js");
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3__);
var _this = undefined,
    _jsxFileName = "D:\\Projects\\Lazyloading\\lazyloading\\with-dynamic-import-app\\pages\\index.js",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



 // const DynamicComponent1 = dynamic(() => import('../components/hello1'))
// const DynamicComponent2WithCustomLoading = dynamic(
//   () => import('../components/hello2'),
//   { loading: () => <p><img src="/blure.jpg"></img>loading......</p> }
// )

var DynamicComponent3WithNoSSR = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(_c = function _c() {
  return __webpack_require__.e(/*! import() */ 1).then(__webpack_require__.bind(null, /*! ../components/hello3 */ "./components/hello3.js"));
}, {
  loading: function loading() {
    return __jsx("div", {
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 22
      }
    }, __jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3___default.a, {
      count: 15,
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 5
      }
    }), "/>", __jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3___default.a, {
      variant: "rect",
      width: 510,
      height: 418,
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 5
      }
    }));
  },
  ssr: false,
  loadableGenerated: {
    webpack: function webpack() {
      return [/*require.resolve*/(/*! ../components/hello3 */ "./components/hello3.js")];
    },
    modules: ['../components/hello3']
  }
}); // const DynamicComponent4 = dynamic(() => import('../components/hello4'))
// const DynamicComponent5 = dynamic(() => import('../components/hello5'))

_c2 = DynamicComponent3WithNoSSR;

var IndexPage = function IndexPage() {
  _s();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      showMore = _useState[0],
      setShowMore = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      falsyField = _useState2[0];

  return __jsx("div", {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 5
    }
  }, __jsx(_components_Header__WEBPACK_IMPORTED_MODULE_1__["default"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }
  }), __jsx(DynamicComponent3WithNoSSR, {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 7
    }
  }));
};

_s(IndexPage, "khxDnRSRfkY5/LeLSQGWUVNCm7U=");

_c3 = IndexPage;
/* harmony default export */ __webpack_exports__["default"] = (IndexPage);

var _c, _c2, _c3;

$RefreshReg$(_c, "DynamicComponent3WithNoSSR$dynamic");
$RefreshReg$(_c2, "DynamicComponent3WithNoSSR");
$RefreshReg$(_c3, "IndexPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiRHluYW1pY0NvbXBvbmVudDNXaXRoTm9TU1IiLCJkeW5hbWljIiwibG9hZGluZyIsInNzciIsIkluZGV4UGFnZSIsInVzZVN0YXRlIiwic2hvd01vcmUiLCJzZXRTaG93TW9yZSIsImZhbHN5RmllbGQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtDQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBTUEsMEJBQTBCLEdBQUdDLG1EQUFPLE1BQ3hDO0FBQUEsU0FBTSxtSUFBTjtBQUFBLENBRHdDLEVBRXhDO0FBQUVDLFNBQU8sRUFBRTtBQUFBLFdBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUNqQixNQUFDLDZEQUFEO0FBQVUsV0FBSyxFQUFFLEVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFEaUIsUUFHakIsTUFBQyw2REFBRDtBQUFVLGFBQU8sRUFBQyxNQUFsQjtBQUF5QixXQUFLLEVBQUUsR0FBaEM7QUFBcUMsWUFBTSxFQUFFLEdBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFIaUIsQ0FBUjtBQUFBLEdBQVg7QUFJU0MsS0FBRyxFQUFFLEtBSmQ7QUFBQTtBQUFBO0FBQUEsa0NBRGEsb0RBQ2I7QUFBQTtBQUFBLGNBRGEsc0JBQ2I7QUFBQTtBQUFBLENBRndDLENBQTFDLEMsQ0FTQTtBQUVBOztNQVhNSCwwQjs7QUFhTixJQUFNSSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxHQUFNO0FBQUE7O0FBQUEsa0JBQ1VDLHNEQUFRLENBQUMsS0FBRCxDQURsQjtBQUFBLE1BQ2ZDLFFBRGU7QUFBQSxNQUNMQyxXQURLOztBQUFBLG1CQUVERixzREFBUSxDQUFDLEtBQUQsQ0FGUDtBQUFBLE1BRWZHLFVBRmU7O0FBSXRCLFNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURGLEVBVUUsTUFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBVkYsQ0FERjtBQXFCRCxDQXpCRDs7R0FBTUosUzs7TUFBQUEsUztBQTJCU0Esd0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguOTQ0NGE1YWVjOTRmMGFjOTllZDkuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgSGVhZGVyIGZyb20gJy4uL2NvbXBvbmVudHMvSGVhZGVyJ1xuaW1wb3J0IGR5bmFtaWMgZnJvbSAnbmV4dC9keW5hbWljJ1xuaW1wb3J0IFNrZWxldG9uLCB7IFNrZWxldG9uVGhlbWUgfSBmcm9tIFwicmVhY3QtbG9hZGluZy1za2VsZXRvblwiO1xuXG4vLyBjb25zdCBEeW5hbWljQ29tcG9uZW50MSA9IGR5bmFtaWMoKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL2hlbGxvMScpKVxuXG4vLyBjb25zdCBEeW5hbWljQ29tcG9uZW50MldpdGhDdXN0b21Mb2FkaW5nID0gZHluYW1pYyhcbi8vICAgKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL2hlbGxvMicpLFxuLy8gICB7IGxvYWRpbmc6ICgpID0+IDxwPjxpbWcgc3JjPVwiL2JsdXJlLmpwZ1wiPjwvaW1nPmxvYWRpbmcuLi4uLi48L3A+IH1cbi8vIClcblxuY29uc3QgRHluYW1pY0NvbXBvbmVudDNXaXRoTm9TU1IgPSBkeW5hbWljKFxuICAoKSA9PiBpbXBvcnQoJy4uL2NvbXBvbmVudHMvaGVsbG8zJyksXG4gIHsgbG9hZGluZzogKCkgPT4gICA8ZGl2PlxuICAgIDxTa2VsZXRvbiBjb3VudD17MTV9IC8+XG4gICAgLz5cbiAgICA8U2tlbGV0b24gdmFyaWFudD1cInJlY3RcIiB3aWR0aD17NTEwfSBoZWlnaHQ9ezQxOH0gLz5cbiAgPC9kaXY+ICwgc3NyOiBmYWxzZSB9XG4pXG5cbi8vIGNvbnN0IER5bmFtaWNDb21wb25lbnQ0ID0gZHluYW1pYygoKSA9PiBpbXBvcnQoJy4uL2NvbXBvbmVudHMvaGVsbG80JykpXG5cbi8vIGNvbnN0IER5bmFtaWNDb21wb25lbnQ1ID0gZHluYW1pYygoKSA9PiBpbXBvcnQoJy4uL2NvbXBvbmVudHMvaGVsbG81JykpXG5cbmNvbnN0IEluZGV4UGFnZSA9ICgpID0+IHtcbiAgY29uc3QgW3Nob3dNb3JlLCBzZXRTaG93TW9yZV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2ZhbHN5RmllbGRdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPEhlYWRlciAvPlxuICAgICAgXG4gICAgICB7LyogTG9hZCBpbW1lZGlhdGVseSwgYnV0IGluIGEgc2VwYXJhdGUgYnVuZGxlICovfVxuICAgICAgey8qIDxEeW5hbWljQ29tcG9uZW50MSAvPiAqL31cblxuICAgICAgey8qIFNob3cgYSBwcm9ncmVzcyBpbmRpY2F0b3Igd2hpbGUgbG9hZGluZyAqL31cbiAgICAgIHsvKiA8RHluYW1pY0NvbXBvbmVudDJXaXRoQ3VzdG9tTG9hZGluZyAvPiAqL31cblxuICAgICAgey8qIExvYWQgb25seSBvbiB0aGUgY2xpZW50IHNpZGUgKi99XG4gICAgICA8RHluYW1pY0NvbXBvbmVudDNXaXRoTm9TU1IgLz5cblxuICAgICAgey8qIFRoaXMgY29tcG9uZW50IHdpbGwgbmV2ZXIgYmUgbG9hZGVkICovfVxuICAgICAgey8qIHtmYWxzeUZpZWxkICYmIDxEeW5hbWljQ29tcG9uZW50NCAvPn0gKi99XG5cbiAgICAgIHsvKiBMb2FkIG9uIGRlbWFuZCAqL31cbiAgICAgIHsvKiB7c2hvd01vcmUgJiYgPER5bmFtaWNDb21wb25lbnQ1IC8+fVxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9yZSghc2hvd01vcmUpfT5Ub2dnbGUgU2hvdyBNb3JlPC9idXR0b24+ICovfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEluZGV4UGFnZVxuIl0sInNvdXJjZVJvb3QiOiIifQ==