webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Header */ "./components/Header.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dynamic */ "./node_modules/next/dist/next-server/lib/dynamic.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-loading-skeleton */ "./node_modules/react-loading-skeleton/lib/index.js");
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3__);
var _this = undefined,
    _jsxFileName = "D:\\Projects\\Lazyloading\\lazyloading\\with-dynamic-import-app\\pages\\index.js",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



 // const DynamicComponent1 = dynamic(() => import('../components/hello1'))
// const DynamicComponent2WithCustomLoading = dynamic(
//   () => import('../components/hello2'),
//   { loading: () => <p><img src="/blure.jpg"></img>loading......</p> }
// )

var DynamicComponent3WithNoSSR = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(_c = function _c() {
  return __webpack_require__.e(/*! import() */ 1).then(__webpack_require__.bind(null, /*! ../components/hello3 */ "./components/hello3.js"));
}, {
  loading: function loading() {
    return __jsx("div", {
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 22
      }
    }, __jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3___default.a, {
      count: 15,
      height: 100,
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 5
      }
    }));
  },
  ssr: false,
  loadableGenerated: {
    webpack: function webpack() {
      return [/*require.resolve*/(/*! ../components/hello3 */ "./components/hello3.js")];
    },
    modules: ['../components/hello3']
  }
}); // const DynamicComponent4 = dynamic(() => import('../components/hello4'))
// const DynamicComponent5 = dynamic(() => import('../components/hello5'))

_c2 = DynamicComponent3WithNoSSR;

var IndexPage = function IndexPage() {
  _s();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      showMore = _useState[0],
      setShowMore = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      falsyField = _useState2[0];

  return __jsx("div", {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 5
    }
  }, __jsx(_components_Header__WEBPACK_IMPORTED_MODULE_1__["default"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }
  }), __jsx(DynamicComponent3WithNoSSR, {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }
  }));
};

_s(IndexPage, "khxDnRSRfkY5/LeLSQGWUVNCm7U=");

_c3 = IndexPage;
/* harmony default export */ __webpack_exports__["default"] = (IndexPage);

var _c, _c2, _c3;

$RefreshReg$(_c, "DynamicComponent3WithNoSSR$dynamic");
$RefreshReg$(_c2, "DynamicComponent3WithNoSSR");
$RefreshReg$(_c3, "IndexPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiRHluYW1pY0NvbXBvbmVudDNXaXRoTm9TU1IiLCJkeW5hbWljIiwibG9hZGluZyIsInNzciIsIkluZGV4UGFnZSIsInVzZVN0YXRlIiwic2hvd01vcmUiLCJzZXRTaG93TW9yZSIsImZhbHN5RmllbGQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtDQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBTUEsMEJBQTBCLEdBQUdDLG1EQUFPLE1BQ3hDO0FBQUEsU0FBTSxtSUFBTjtBQUFBLENBRHdDLEVBRXhDO0FBQUVDLFNBQU8sRUFBRTtBQUFBLFdBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUNqQixNQUFDLDZEQUFEO0FBQVUsV0FBSyxFQUFFLEVBQWpCO0FBQXFCLFlBQU0sRUFBRSxHQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRGlCLENBQVI7QUFBQSxHQUFYO0FBR1NDLEtBQUcsRUFBRSxLQUhkO0FBQUE7QUFBQTtBQUFBLGtDQURhLG9EQUNiO0FBQUE7QUFBQSxjQURhLHNCQUNiO0FBQUE7QUFBQSxDQUZ3QyxDQUExQyxDLENBUUE7QUFFQTs7TUFWTUgsMEI7O0FBWU4sSUFBTUksU0FBUyxHQUFHLFNBQVpBLFNBQVksR0FBTTtBQUFBOztBQUFBLGtCQUNVQyxzREFBUSxDQUFDLEtBQUQsQ0FEbEI7QUFBQSxNQUNmQyxRQURlO0FBQUEsTUFDTEMsV0FESzs7QUFBQSxtQkFFREYsc0RBQVEsQ0FBQyxLQUFELENBRlA7QUFBQSxNQUVmRyxVQUZlOztBQUl0QixTQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRSxNQUFDLDBEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFERixFQVVFLE1BQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVZGLENBREY7QUFxQkQsQ0F6QkQ7O0dBQU1KLFM7O01BQUFBLFM7QUEyQlNBLHdFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjJjNzEyNjczYWVlNjdlMWRmMzg2LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEhlYWRlciBmcm9tICcuLi9jb21wb25lbnRzL0hlYWRlcidcbmltcG9ydCBkeW5hbWljIGZyb20gJ25leHQvZHluYW1pYydcbmltcG9ydCBTa2VsZXRvbiwgeyBTa2VsZXRvblRoZW1lIH0gZnJvbSBcInJlYWN0LWxvYWRpbmctc2tlbGV0b25cIjtcblxuLy8gY29uc3QgRHluYW1pY0NvbXBvbmVudDEgPSBkeW5hbWljKCgpID0+IGltcG9ydCgnLi4vY29tcG9uZW50cy9oZWxsbzEnKSlcblxuLy8gY29uc3QgRHluYW1pY0NvbXBvbmVudDJXaXRoQ3VzdG9tTG9hZGluZyA9IGR5bmFtaWMoXG4vLyAgICgpID0+IGltcG9ydCgnLi4vY29tcG9uZW50cy9oZWxsbzInKSxcbi8vICAgeyBsb2FkaW5nOiAoKSA9PiA8cD48aW1nIHNyYz1cIi9ibHVyZS5qcGdcIj48L2ltZz5sb2FkaW5nLi4uLi4uPC9wPiB9XG4vLyApXG5cbmNvbnN0IER5bmFtaWNDb21wb25lbnQzV2l0aE5vU1NSID0gZHluYW1pYyhcbiAgKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL2hlbGxvMycpLFxuICB7IGxvYWRpbmc6ICgpID0+ICAgPGRpdj5cbiAgICA8U2tlbGV0b24gY291bnQ9ezE1fSBoZWlnaHQ9ezEwMH0gLz5cbiAgXG4gIDwvZGl2PiAsIHNzcjogZmFsc2UgfVxuKVxuXG4vLyBjb25zdCBEeW5hbWljQ29tcG9uZW50NCA9IGR5bmFtaWMoKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL2hlbGxvNCcpKVxuXG4vLyBjb25zdCBEeW5hbWljQ29tcG9uZW50NSA9IGR5bmFtaWMoKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL2hlbGxvNScpKVxuXG5jb25zdCBJbmRleFBhZ2UgPSAoKSA9PiB7XG4gIGNvbnN0IFtzaG93TW9yZSwgc2V0U2hvd01vcmVdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtmYWxzeUZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxIZWFkZXIgLz5cbiAgICAgIFxuICAgICAgey8qIExvYWQgaW1tZWRpYXRlbHksIGJ1dCBpbiBhIHNlcGFyYXRlIGJ1bmRsZSAqL31cbiAgICAgIHsvKiA8RHluYW1pY0NvbXBvbmVudDEgLz4gKi99XG5cbiAgICAgIHsvKiBTaG93IGEgcHJvZ3Jlc3MgaW5kaWNhdG9yIHdoaWxlIGxvYWRpbmcgKi99XG4gICAgICB7LyogPER5bmFtaWNDb21wb25lbnQyV2l0aEN1c3RvbUxvYWRpbmcgLz4gKi99XG5cbiAgICAgIHsvKiBMb2FkIG9ubHkgb24gdGhlIGNsaWVudCBzaWRlICovfVxuICAgICAgPER5bmFtaWNDb21wb25lbnQzV2l0aE5vU1NSIC8+XG5cbiAgICAgIHsvKiBUaGlzIGNvbXBvbmVudCB3aWxsIG5ldmVyIGJlIGxvYWRlZCAqL31cbiAgICAgIHsvKiB7ZmFsc3lGaWVsZCAmJiA8RHluYW1pY0NvbXBvbmVudDQgLz59ICovfVxuXG4gICAgICB7LyogTG9hZCBvbiBkZW1hbmQgKi99XG4gICAgICB7Lyoge3Nob3dNb3JlICYmIDxEeW5hbWljQ29tcG9uZW50NSAvPn1cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd01vcmUoIXNob3dNb3JlKX0+VG9nZ2xlIFNob3cgTW9yZTwvYnV0dG9uPiAqL31cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBJbmRleFBhZ2VcbiJdLCJzb3VyY2VSb290IjoiIn0=