webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Header */ "./components/Header.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dynamic */ "./node_modules/next/dist/next-server/lib/dynamic.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-loading-skeleton */ "./node_modules/react-loading-skeleton/lib/index.js");
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3__);
var _this = undefined,
    _jsxFileName = "D:\\Projects\\Lazyloading\\lazyloading\\with-dynamic-import-app\\pages\\index.js",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



 // const DynamicComponent1 = dynamic(() => import('../components/hello1'))
// const DynamicComponent2WithCustomLoading = dynamic(
//   () => import('../components/hello2'),
//   { loading: () => <p><img src="/blure.jpg"></img>loading......</p> }
// )

var DynamicComponent3WithNoSSR = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(_c = function _c() {
  return __webpack_require__.e(/*! import() */ 1).then(__webpack_require__.bind(null, /*! ../components/hello3 */ "./components/hello3.js"));
}, {
  loading: function loading() {
    return __jsx("div", {
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 22
      }
    }, __jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_3___default.a, {
      count: 15,
      height: 20,
      width: 500,
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 5
      }
    }));
  },
  ssr: false,
  loadableGenerated: {
    webpack: function webpack() {
      return [/*require.resolve*/(/*! ../components/hello3 */ "./components/hello3.js")];
    },
    modules: ['../components/hello3']
  }
}); // const DynamicComponent4 = dynamic(() => import('../components/hello4'))
// const DynamicComponent5 = dynamic(() => import('../components/hello5'))

_c2 = DynamicComponent3WithNoSSR;

var IndexPage = function IndexPage() {
  _s();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      showMore = _useState[0],
      setShowMore = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
      falsyField = _useState2[0];

  return __jsx("div", {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 5
    }
  }, __jsx(_components_Header__WEBPACK_IMPORTED_MODULE_1__["default"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }
  }), __jsx(DynamicComponent3WithNoSSR, {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }
  }));
};

_s(IndexPage, "khxDnRSRfkY5/LeLSQGWUVNCm7U=");

_c3 = IndexPage;
/* harmony default export */ __webpack_exports__["default"] = (IndexPage);

var _c, _c2, _c3;

$RefreshReg$(_c, "DynamicComponent3WithNoSSR$dynamic");
$RefreshReg$(_c2, "DynamicComponent3WithNoSSR");
$RefreshReg$(_c3, "IndexPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiRHluYW1pY0NvbXBvbmVudDNXaXRoTm9TU1IiLCJkeW5hbWljIiwibG9hZGluZyIsInNzciIsIkluZGV4UGFnZSIsInVzZVN0YXRlIiwic2hvd01vcmUiLCJzZXRTaG93TW9yZSIsImZhbHN5RmllbGQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtDQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBTUEsMEJBQTBCLEdBQUdDLG1EQUFPLE1BQ3hDO0FBQUEsU0FBTSxtSUFBTjtBQUFBLENBRHdDLEVBRXhDO0FBQUVDLFNBQU8sRUFBRTtBQUFBLFdBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUNqQixNQUFDLDZEQUFEO0FBQVUsV0FBSyxFQUFFLEVBQWpCO0FBQXFCLFlBQU0sRUFBRSxFQUE3QjtBQUFpQyxXQUFLLEVBQUUsR0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQURpQixDQUFSO0FBQUEsR0FBWDtBQUdTQyxLQUFHLEVBQUUsS0FIZDtBQUFBO0FBQUE7QUFBQSxrQ0FEYSxvREFDYjtBQUFBO0FBQUEsY0FEYSxzQkFDYjtBQUFBO0FBQUEsQ0FGd0MsQ0FBMUMsQyxDQVFBO0FBRUE7O01BVk1ILDBCOztBQVlOLElBQU1JLFNBQVMsR0FBRyxTQUFaQSxTQUFZLEdBQU07QUFBQTs7QUFBQSxrQkFDVUMsc0RBQVEsQ0FBQyxLQUFELENBRGxCO0FBQUEsTUFDZkMsUUFEZTtBQUFBLE1BQ0xDLFdBREs7O0FBQUEsbUJBRURGLHNEQUFRLENBQUMsS0FBRCxDQUZQO0FBQUEsTUFFZkcsVUFGZTs7QUFJdEIsU0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQywwREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsRUFVRSxNQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFWRixDQURGO0FBcUJELENBekJEOztHQUFNSixTOztNQUFBQSxTO0FBMkJTQSx3RUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC42NDVkM2M2NTAwNWZiOTdiYTg4MS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBIZWFkZXIgZnJvbSAnLi4vY29tcG9uZW50cy9IZWFkZXInXG5pbXBvcnQgZHluYW1pYyBmcm9tICduZXh0L2R5bmFtaWMnXG5pbXBvcnQgU2tlbGV0b24sIHsgU2tlbGV0b25UaGVtZSB9IGZyb20gXCJyZWFjdC1sb2FkaW5nLXNrZWxldG9uXCI7XG5cbi8vIGNvbnN0IER5bmFtaWNDb21wb25lbnQxID0gZHluYW1pYygoKSA9PiBpbXBvcnQoJy4uL2NvbXBvbmVudHMvaGVsbG8xJykpXG5cbi8vIGNvbnN0IER5bmFtaWNDb21wb25lbnQyV2l0aEN1c3RvbUxvYWRpbmcgPSBkeW5hbWljKFxuLy8gICAoKSA9PiBpbXBvcnQoJy4uL2NvbXBvbmVudHMvaGVsbG8yJyksXG4vLyAgIHsgbG9hZGluZzogKCkgPT4gPHA+PGltZyBzcmM9XCIvYmx1cmUuanBnXCI+PC9pbWc+bG9hZGluZy4uLi4uLjwvcD4gfVxuLy8gKVxuXG5jb25zdCBEeW5hbWljQ29tcG9uZW50M1dpdGhOb1NTUiA9IGR5bmFtaWMoXG4gICgpID0+IGltcG9ydCgnLi4vY29tcG9uZW50cy9oZWxsbzMnKSxcbiAgeyBsb2FkaW5nOiAoKSA9PiAgIDxkaXY+XG4gICAgPFNrZWxldG9uIGNvdW50PXsxNX0gaGVpZ2h0PXsyMH0gd2lkdGg9ezUwMH0gLz5cbiAgXG4gIDwvZGl2PiAsIHNzcjogZmFsc2UgfVxuKVxuXG4vLyBjb25zdCBEeW5hbWljQ29tcG9uZW50NCA9IGR5bmFtaWMoKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL2hlbGxvNCcpKVxuXG4vLyBjb25zdCBEeW5hbWljQ29tcG9uZW50NSA9IGR5bmFtaWMoKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL2hlbGxvNScpKVxuXG5jb25zdCBJbmRleFBhZ2UgPSAoKSA9PiB7XG4gIGNvbnN0IFtzaG93TW9yZSwgc2V0U2hvd01vcmVdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtmYWxzeUZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxIZWFkZXIgLz5cbiAgICAgIFxuICAgICAgey8qIExvYWQgaW1tZWRpYXRlbHksIGJ1dCBpbiBhIHNlcGFyYXRlIGJ1bmRsZSAqL31cbiAgICAgIHsvKiA8RHluYW1pY0NvbXBvbmVudDEgLz4gKi99XG5cbiAgICAgIHsvKiBTaG93IGEgcHJvZ3Jlc3MgaW5kaWNhdG9yIHdoaWxlIGxvYWRpbmcgKi99XG4gICAgICB7LyogPER5bmFtaWNDb21wb25lbnQyV2l0aEN1c3RvbUxvYWRpbmcgLz4gKi99XG5cbiAgICAgIHsvKiBMb2FkIG9ubHkgb24gdGhlIGNsaWVudCBzaWRlICovfVxuICAgICAgPER5bmFtaWNDb21wb25lbnQzV2l0aE5vU1NSIC8+XG5cbiAgICAgIHsvKiBUaGlzIGNvbXBvbmVudCB3aWxsIG5ldmVyIGJlIGxvYWRlZCAqL31cbiAgICAgIHsvKiB7ZmFsc3lGaWVsZCAmJiA8RHluYW1pY0NvbXBvbmVudDQgLz59ICovfVxuXG4gICAgICB7LyogTG9hZCBvbiBkZW1hbmQgKi99XG4gICAgICB7Lyoge3Nob3dNb3JlICYmIDxEeW5hbWljQ29tcG9uZW50NSAvPn1cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd01vcmUoIXNob3dNb3JlKX0+VG9nZ2xlIFNob3cgTW9yZTwvYnV0dG9uPiAqL31cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBJbmRleFBhZ2VcbiJdLCJzb3VyY2VSb290IjoiIn0=