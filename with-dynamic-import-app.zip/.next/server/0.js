exports.ids = [0];
exports.modules = {

/***/ "./components/hello3.js":
/*!******************************!*\
  !*** ./components/hello3.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Hello3; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "D:\\Projects\\Lazyloading\\lazyloading\\with-dynamic-import-app\\components\\hello3.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;
function Hello3() {
  return __jsx("img", {
    src: "/main.jpg",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 2,
      columnNumber: 10
    }
  });
}

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL2hlbGxvMy5qcyJdLCJuYW1lcyI6WyJIZWxsbzMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFlLFNBQVNBLE1BQVQsR0FBa0I7QUFDL0IsU0FBTztBQUFLLE9BQUcsRUFBQyxXQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFBUDtBQUNELEMiLCJmaWxlIjoiMC5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhlbGxvMygpIHtcbiAgcmV0dXJuIDxpbWcgc3JjPVwiL21haW4uanBnXCI+PC9pbWc+XG59XG4iXSwic291cmNlUm9vdCI6IiJ9