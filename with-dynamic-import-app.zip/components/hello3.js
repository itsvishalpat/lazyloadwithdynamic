export default function Hello3() {
  return <img src="/main.jpg"></img>
}
