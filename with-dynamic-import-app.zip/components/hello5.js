export default function Hello5() {
  return <p>Hello World 5 (imported dynamically) </p>
}
