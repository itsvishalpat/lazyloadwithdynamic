export default function Hello4() {
  return <p>Hello World 4 (imported dynamically) </p>
}
