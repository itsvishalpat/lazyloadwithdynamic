export default function Hello2() {
  return <p><img src="/main.jpg"></img></p>
}
