export default function Hello1() {
  return <p>Hello World 1 (imported dynamically) </p>
}
